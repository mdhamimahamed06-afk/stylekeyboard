plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.stylekeyboard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.stylekeyboard"
        minSdk = 23
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// ---- iOS-এর মতো দেখতে ফ্রি ফন্ট (Inter + Hind Siliguri, OFL লাইসেন্স) বিল্ডের সময় নামে ----
// কোনো লিংক কাজ না করলে সিস্টেম ফন্ট চলবে, বিল্ড ভাঙবে না।
val fontCandidates: Map<String, List<String>> = mapOf(
    "english.ttf" to listOf(
        "https://raw.githubusercontent.com/google/fonts/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf",
        "https://raw.githubusercontent.com/google/fonts/main/ofl/inter/Inter%5Bslnt%2Cwght%5D.ttf"
    ),
    "bangla.ttf" to listOf(
        "https://raw.githubusercontent.com/google/fonts/main/ofl/hindsiliguri/HindSiliguri-Regular.ttf",
        "https://raw.githubusercontent.com/google/fonts/main/ofl/notosansbengali/NotoSansBengali%5Bwdth%2Cwght%5D.ttf"
    )
)

val downloadFonts by tasks.registering {
    val dir = layout.projectDirectory.dir("src/main/assets/fonts").asFile
    doLast {
        dir.mkdirs()
        fontCandidates.forEach { (name, links) ->
            val target = File(dir, name)
            if (!target.exists()) {
                var done = false
                for (link in links) {
                    if (done) break
                    val tmp = File(dir, "$name.tmp")
                    try {
                        java.net.URL(link).openStream().use { input ->
                            tmp.outputStream().use { out -> input.copyTo(out) }
                        }
                        if (tmp.length() > 20000L && tmp.renameTo(target)) {
                            done = true
                            println("Font ready: $name <- $link")
                        }
                    } catch (e: Exception) {
                        println("Font link failed: $link ($e)")
                    } finally {
                        if (tmp.exists()) tmp.delete()
                    }
                }
                if (!done) println("Font skipped (system font will be used): $name")
            }
        }
    }
}

tasks.configureEach {
    if (name == "preBuild" || (name.startsWith("merge") && name.endsWith("Assets"))) {
        dependsOn(downloadFonts)
    }
}
