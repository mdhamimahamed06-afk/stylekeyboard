package com.example.stylekeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

private fun c(hex: String): Int = Color.parseColor(hex)

class KeyboardService : InputMethodService() {

    private enum class Mode { EN, BN, EMOJI }

    private class Page(val title: String, val keys: List<String>, val perRow: Int)

    private class Theme(
        val name: String,
        val bg: Int,
        val key: Int,
        val special: Int,
        val accent: Int,
        val text: Int,
        val shadow: Int
    )

    private class EmojiCat(val icon: String, val items: List<String>)

    // ---------- ডেটা ----------

    private val pages = listOf(
        Page(
            "ব্যঞ্জন",
            "ক খ গ ঘ ঙ চ ছ জ ঝ ঞ ট ঠ ড ঢ ণ ত থ দ ধ ন প ফ ব ভ ম য র ল শ ষ স হ ড় ঢ় য় ক্ষ".split(" "),
            9
        ),
        Page(
            "স্বর / কার",
            "অ আ ই ঈ উ ঊ ঋ এ ঐ ও ঔ া ি ী ু ূ ৃ ে ৈ ো ৌ ্ ৎ ং ঃ ঁ জ্ঞ".split(" "),
            9
        ),
        Page(
            "১২৩",
            "০ ১ ২ ৩ ৪ ৫ ৬ ৭ ৮ ৯ । , . ? ! - ( ) : ; ' \" ৳ %".split(" "),
            10
        )
    )

    private val themes = listOf(
        Theme("iOS Light", c("#D1D3D9"), c("#FFFFFF"), c("#ACB1BD"), c("#007AFF"), c("#000000"), c("#8A8B8F")),
        Theme("iOS Dark", c("#2A2A2C"), c("#5B5B5F"), c("#3E3E41"), c("#0A84FF"), c("#FFFFFF"), c("#000000")),
        Theme("Dark", c("#1B1B1F"), c("#34353B"), c("#4A4C55"), c("#3B7DDD"), c("#FFFFFF"), c("#0E0E10")),
        Theme("Pink", c("#FFD9E8"), c("#FFFFFF"), c("#FF9EC4"), c("#E91E63"), c("#4A1030"), c("#D890B0")),
        Theme("Ocean", c("#0D2B45"), c("#1D4E73"), c("#163A58"), c("#00B4D8"), c("#FFFFFF"), c("#071A2B")),
        Theme("Green", c("#D7F0DD"), c("#FFFFFF"), c("#8FD19E"), c("#2E9E4F"), c("#10301A"), c("#7DB88A"))
    )

    private val emojiCats = listOf(
        EmojiCat(
            "😀",
            ("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😍 🥰 😘 😗 😋 😛 😜 🤪 😎 🤩 🥳 😏 😒 😞 😔 " +
                "😟 😕 🙁 😣 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 🤗 🤔 🤭 🤫 😶 😐 😴 🤤 😷 " +
                "🤒 🤕 🤢 🤮 🥴 😈 👿 💀 👻 👽 🤖 💩").split(" ")
        ),
        EmojiCat(
            "👍",
            ("👍 👎 👌 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ✋ 🤚 👋 👏 🙌 👐 🤲 🙏 🤝 💪 👊 ✊ 🤛 🤜 👀 👅 👄 " +
                "🧠 👣").split(" ")
        ),
        EmojiCat(
            "❤️",
            ("❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 💕 💞 💓 💗 💖 💘 💝 💟 ✨ 💫 ⭐ 🌟 🔥 💥 💯 💢 💦 " +
                "💤 🎉 🎊 🎁 🏆 👑 💎").split(" ")
        ),
        EmojiCat(
            "🐶",
            ("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 " +
                "🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐢 🐍 🐙 🦀 🐠 🐬 🐳 🌹 🌸 🌻 🌴 🌲 🍀 🌈 🌙").split(" ")
        ),
        EmojiCat(
            "🍔",
            ("🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥕 🌽 🥔 🍞 🧀 🍗 🍖 🍔 🍟 🍕 🌭 🌮 🌯 🍜 " +
                "🍝 🍣 🍤 🍚 🍦 🍩 🍪 🎂 🍰 🍫 🍬 ☕ 🍵 🥤 🍺 🍷").split(" ")
        ),
        EmojiCat(
            "⚽",
            ("⚽ 🏀 🏈 ⚾ 🎾 🏐 🏏 🎱 🏓 🥊 🎮 🎯 🎲 🎧 🎤 🎸 🎬 🚗 🚕 🚌 🚓 🚑 🚀 🚲 🚢 🏠 🏫 " +
                "🏥 🕌").split(" ")
        ),
        EmojiCat(
            "💡",
            ("📱 💻 📷 📞 ⏰ 💡 🔋 🔑 🔒 💰 💵 💳 📚 📌 📎 🔔 🎈 ✅ ❌ ❓ ❗ ➕ ➖ ⭕ 🔴 🟢 🔵 " +
                "⚪ ⚫ 🚫").split(" ")
        )
    )

    // ---------- অবস্থা ----------

    private var mode = Mode.EN
    private var textMode = Mode.EN
    private var shift = false
    private var styleIdx = 0
    private var pageIdx = 0
    private var emojiIdx = 0
    private var themeIdx = 0

    private var enFont: Typeface? = null
    private var bnFont: Typeface? = null

    private var root: LinearLayout? = null
    private var chipHolder: LinearLayout? = null
    private var keysArea: LinearLayout? = null
    private var bottomHolder: LinearLayout? = null
    private val chips = mutableListOf<TextView>()

    private val handler = Handler(Looper.getMainLooper())
    private val repeatDelete = object : Runnable {
        override fun run() {
            backspace()
            handler.postDelayed(this, 60)
        }
    }

    private val theme: Theme get() = themes[themeIdx]

    // ---------- সাহায্যকারী ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun loadFont(name: String): Typeface? = try {
        Typeface.createFromAsset(assets, "fonts/$name")
    } catch (e: Exception) {
        null
    }

    private fun currentFont(): Typeface? = when (mode) {
        Mode.BN -> bnFont
        Mode.EN -> enFont
        else -> null
    }

    private fun keyBg(color: Int): Drawable {
        val shadow = GradientDrawable().apply {
            setColor(theme.shadow)
            cornerRadius = dp(6).toFloat()
        }
        val face = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(6).toFloat()
        }
        return LayerDrawable(arrayOf<Drawable>(shadow, face)).apply {
            setLayerInset(1, 0, 0, 0, dp(1))
        }
    }

    /** kind: 0 = সাধারণ, 1 = বিশেষ, 2 = অ্যাকসেন্ট, 3 = ব্যাকগ্রাউন্ডহীন (ইমোজি) */
    private fun makeKey(
        label: String,
        weight: Float,
        sizeSp: Float = 19f,
        kind: Int = 0,
        font: Typeface? = currentFont(),
        onClick: () -> Unit
    ): TextView {
        val t = theme
        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = sizeSp
            if (font != null) typeface = font
            when (kind) {
                0 -> {
                    setTextColor(t.text)
                    background = keyBg(t.key)
                }
                1 -> {
                    setTextColor(t.text)
                    background = keyBg(t.special)
                }
                2 -> {
                    setTextColor(Color.WHITE)
                    background = keyBg(t.accent)
                }
                else -> setTextColor(t.text)
            }
            layoutParams = LinearLayout.LayoutParams(0, dp(46), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onClick()
            }
        }
    }

    private fun newRow(weightSum: Float = 0f): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        if (weightSum > 0f) setWeightSum(weightSum)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun markLabel(s: String): String {
        val t = Character.getType(s[0])
        val mark = t == Character.NON_SPACING_MARK.toInt() ||
            t == Character.COMBINING_SPACING_MARK.toInt()
        return if (mark) "◌$s" else s
    }

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
            return
        }
        val before = ic.getTextBeforeCursor(2, 0)
        var n = 1
        if (before != null && before.length == 2) {
            val a = before[0]
            val b = before[1]
            if (b == '̶' || b == '̲' || b == '️') {
                n = 2 // strike/underline/ইমোজি ভ্যারিয়েন্ট: অক্ষর + চিহ্ন একসাথে
            } else if (Character.isHighSurrogate(a) && Character.isLowSurrogate(b)) {
                n = 2 // স্টাইলিশ অক্ষর / ইমোজি (surrogate pair)
            }
        }
        ic.deleteSurroundingText(n, 0)
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun commitLetter(ch: Char) {
        val letter = if (shift) ch.uppercaseChar() else ch
        commit(StyleMaps.all[styleIdx].apply(letter))
        if (shift) {
            shift = false
            buildKeys()
        }
    }

    private fun switchKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }

    private fun rebuildAll() {
        buildChips()
        buildKeys()
        buildBottom()
    }

    private fun applyTheme() {
        root?.setBackgroundColor(theme.bg)
        rebuildAll()
    }

    private fun cycleTheme() {
        themeIdx = (themeIdx + 1) % themes.size
        getSharedPreferences("kb", Context.MODE_PRIVATE)
            .edit().putInt("theme", themeIdx).apply()
        applyTheme()
    }

    // ---------- লাইফসাইকেল ----------

    override fun onCreate() {
        super.onCreate()
        enFont = loadFont("english.ttf")
        bnFont = loadFont("bangla.ttf")
        themeIdx = getSharedPreferences("kb", Context.MODE_PRIVATE)
            .getInt("theme", 0).coerceIn(0, themes.size - 1)
    }

    override fun onCreateInputView(): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(theme.bg)
            setPadding(dp(2), dp(2), dp(2), dp(6))
        }
        val chipH = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val keys = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val full = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        r.addView(chipH, LinearLayout.LayoutParams(full, wrap))
        r.addView(keys, LinearLayout.LayoutParams(full, wrap))
        r.addView(bottom, LinearLayout.LayoutParams(full, wrap))
        root = r
        chipHolder = chipH
        keysArea = keys
        bottomHolder = bottom
        rebuildAll()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        shift = false
        buildKeys()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        handler.removeCallbacks(repeatDelete)
        super.onFinishInputView(finishingInput)
    }

    // ---------- উপরের বার (থিম + স্টাইল / পেজ / ইমোজি ক্যাটাগরি) ----------

    private fun recolorChips(selected: Int) {
        val t = theme
        chips.forEachIndexed { j, chip ->
            val sel = j == selected
            chip.background = keyBg(if (sel) t.accent else t.key)
            chip.setTextColor(if (sel) Color.WHITE else t.text)
        }
    }

    private fun buildChips() {
        val holder = chipHolder ?: return
        holder.removeAllViews()
        chips.clear()
        val t = theme
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val themeChip = TextView(this).apply {
            text = "🎨"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = keyBg(t.special)
            layoutParams = LinearLayout.LayoutParams(wrap, wrap).apply {
                setMargins(dp(6), dp(4), dp(3), 0)
            }
            setOnClickListener { cycleTheme() }
        }
        holder.addView(themeChip)

        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(2), dp(4), dp(4), 0)
        }
        val names: List<String> = when (mode) {
            Mode.BN -> pages.map { it.title }
            Mode.EMOJI -> emojiCats.map { it.icon }
            else -> StyleMaps.all.map { it.sample }
        }
        val selected = when (mode) {
            Mode.BN -> pageIdx
            Mode.EMOJI -> emojiIdx
            else -> styleIdx
        }

        names.forEachIndexed { i, n ->
            val chip = TextView(this).apply {
                text = n
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(6), dp(14), dp(6))
                if (mode == Mode.BN && bnFont != null) typeface = bnFont
                layoutParams = LinearLayout.LayoutParams(wrap, wrap).apply {
                    setMargins(dp(3), 0, dp(3), 0)
                }
            }
            chip.setOnClickListener {
                when (mode) {
                    Mode.BN -> {
                        pageIdx = i
                        buildKeys()
                    }
                    Mode.EMOJI -> {
                        emojiIdx = i
                        buildKeys()
                    }
                    else -> {
                        styleIdx = i
                        buildBottom()
                    }
                }
                recolorChips(i)
            }
            chips.add(chip)
            row.addView(chip)
        }
        scroll.addView(row)
        holder.addView(scroll, LinearLayout.LayoutParams(0, wrap, 1f))
        recolorChips(selected)
    }

    // ---------- কী-এর এলাকা ----------

    private fun buildKeys() {
        val area = keysArea ?: return
        area.removeAllViews()
        when (mode) {
            Mode.BN -> {
                val p = pages[pageIdx]
                p.keys.chunked(p.perRow).forEach { chunk ->
                    val row = newRow(p.perRow.toFloat())
                    chunk.forEach { k ->
                        row.addView(makeKey(markLabel(k), 1f, 20f) { commit(k) })
                    }
                    area.addView(row)
                }
            }
            Mode.EMOJI -> {
                val cat = emojiCats[emojiIdx]
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                cat.items.chunked(8).forEach { chunk ->
                    val row = newRow(8f)
                    chunk.forEach { e ->
                        row.addView(makeKey(e, 1f, 24f, 3, null) { commit(e) })
                    }
                    col.addView(row)
                }
                val sv = ScrollView(this)
                sv.addView(col)
                area.addView(
                    sv,
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(208))
                )
            }
            else -> {
                area.addView(letterRow("1234567890", 0f))
                area.addView(letterRow("qwertyuiop", 0f))
                area.addView(letterRow("asdfghjkl", 0.5f))

                val row4 = newRow()
                row4.addView(makeKey(if (shift) "⇪" else "⇧", 1.5f, 18f, 1, null) {
                    shift = !shift
                    buildKeys()
                })
                "zxcvbnm".forEach { ch -> row4.addView(letterKey(ch)) }
                row4.addView(deleteKey(1.5f))
                area.addView(row4)
            }
        }
    }

    private fun letterKey(ch: Char): TextView {
        val shown = if (shift && ch.isLetter()) ch.uppercaseChar() else ch
        return makeKey(shown.toString(), 1f) { commitLetter(ch) }
    }

    private fun letterRow(chars: String, side: Float): LinearLayout {
        val row = newRow(10f)
        if (side > 0f) row.addView(spacer(side))
        chars.forEach { row.addView(letterKey(it)) }
        if (side > 0f) row.addView(spacer(side))
        return row
    }

    private fun spacer(weight: Float): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, dp(46), weight)
    }

    private fun deleteKey(weight: Float): TextView =
        makeKey("⌫", weight, 18f, 1, null) {}.apply {
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        backspace()
                        handler.postDelayed(repeatDelete, 400)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        handler.removeCallbacks(repeatDelete)
                }
                true
            }
        }

    // ---------- নিচের সারি ----------

    private fun buildBottom() {
        val holder = bottomHolder ?: return
        holder.removeAllViews()

        if (mode == Mode.EMOJI) {
            holder.addView(makeKey(if (textMode == Mode.BN) "অআ" else "ABC", 1.5f, 16f, 1, null) {
                mode = textMode
                shift = false
                rebuildAll()
            })
            holder.addView(makeKey("🌐", 1f, 16f, 1, null) { switchKeyboard() })
            holder.addView(makeKey("space", 4f, 14f, 0, null) { commit(" ") })
            holder.addView(deleteKey(1.5f))
            holder.addView(makeKey("⏎", 1.5f, 18f, 2, null) { enter() })
            return
        }

        val bn = mode == Mode.BN
        holder.addView(makeKey(if (bn) "EN" else "বাং", 1.4f, 16f, 1, null) {
            textMode = if (bn) Mode.EN else Mode.BN
            mode = textMode
            shift = false
            rebuildAll()
        })
        holder.addView(makeKey("😊", 1f, 16f, 1, null) {
            textMode = mode
            mode = Mode.EMOJI
            rebuildAll()
        })
        holder.addView(makeKey("🌐", 1f, 16f, 1, null) { switchKeyboard() })
        holder.addView(makeKey(",", 0.8f) { commit(",") })

        val spaceLabel = if (bn) "বাংলা" else StyleMaps.all[styleIdx].name
        holder.addView(makeKey(spaceLabel, if (bn) 2.6f else 3.4f, 14f) { commit(" ") })

        holder.addView(makeKey(if (bn) "।" else ".", 0.8f) { commit(if (bn) "।" else ".") })
        if (bn) holder.addView(deleteKey(1.3f))
        holder.addView(makeKey("⏎", 1.4f, 18f, 2, null) { enter() })
    }
}
