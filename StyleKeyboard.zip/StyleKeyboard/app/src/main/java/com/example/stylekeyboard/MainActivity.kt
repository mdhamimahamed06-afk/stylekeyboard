package com.example.stylekeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        col.addView(TextView(this).apply {
            text = "✨ StyloKey"
            textSize = 30f
        })
        col.addView(TextView(this).apply {
            text = "বাংলা + ইংরেজি কিবোর্ড, স্টাইলিশ টেক্সট (𝗕𝗼𝗹𝗱, 𝓢𝓬𝓻𝓲𝓹𝓽, ᴄᴜᴛᴇ…), ইমোজি, থিম আর ভয়েস টাইপিং\n\n" +
                "১. প্রথম বোতামে চাপ দিয়ে \"StyloKey\" চালু করুন।\n" +
                "২. দ্বিতীয় বোতামে চাপ দিয়ে এই কিবোর্ড বেছে নিন।\n" +
                "৩. তৃতীয় বোতামে চাপ দিয়ে মাইক্রোফোনের অনুমতি দিন (ভয়েস টাইপিংয়ের জন্য)।\n" +
                "৪. নিচের ঘরে টাইপ করে দেখুন।\n\n" +
                "কিবোর্ডের উপরের সারিতে: 🎨 থিম বদলায়, 🎤 ভয়েসে লেখা, Aa কিবোর্ডের সাইজ বদলায়।\n" +
                "ভয়েসে বাংলা লিখতে \"বাং\" মোডে মাইকে চাপ দিয়ে বাংলায় বলুন। ইন্টারনেট লাগবে।"
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 2)
        })

        col.addView(Button(this).apply {
            text = "১. কিবোর্ড চালু করুন"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })
        col.addView(Button(this).apply {
            text = "২. কিবোর্ড বেছে নিন"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        col.addView(Button(this).apply {
            text = "৩. মাইক্রোফোনের অনুমতি দিন"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, PermissionActivity::class.java))
            }
        })
        col.addView(EditText(this).apply {
            hint = "এখানে টাইপ করে দেখুন"
            minLines = 3
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
