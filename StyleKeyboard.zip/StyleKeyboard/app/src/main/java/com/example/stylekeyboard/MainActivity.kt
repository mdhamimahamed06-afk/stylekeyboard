package com.example.stylekeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        col.addView(TextView(this).apply {
            text = "Style Keyboard"
            textSize = 26f
        })
        col.addView(TextView(this).apply {
            text = "বাংলা টাইপিং + স্টাইলিশ টেক্সট (𝗕𝗼𝗹𝗱, 𝓢𝓬𝓻𝓲𝓹𝓽, ᴄᴜᴛᴇ…)\n\n" +
                "১. নিচের প্রথম বোতামে চাপ দিয়ে \"Style Keyboard\" চালু করুন।\n" +
                "২. দ্বিতীয় বোতামে চাপ দিয়ে এই কিবোর্ড বেছে নিন।\n" +
                "৩. নিচের ঘরে টাইপ করে দেখুন। \"বাং\" বোতামে বাংলা/ইংরেজি বদলাবে, " +
                "উপরের বারে স্টাইল বদলাবে।"
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 2)
        })

        col.addView(Button(this).apply {
            text = "১. কিবোর্ড চালু করুন"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })
        col.addView(Button(this).apply {
            text = "২. কিবোর্ড বেছে নিন"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        col.addView(EditText(this).apply {
            hint = "এখানে টাইপ করে দেখুন"
            minLines = 3
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
