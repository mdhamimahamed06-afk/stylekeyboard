package com.example.stylekeyboard

/** Unicode স্টাইল ম্যাপ: সাধারণ অক্ষরকে স্টাইলিশ অক্ষরে বদলায়। */
object StyleMaps {

    class Style(val name: String, val sample: String, private val f: (Char) -> String) {
        fun apply(c: Char): String = f(c)
    }

    private fun cp(x: Int): String = String(Character.toChars(x))

    private fun math(
        upper: Int,
        lower: Int,
        digit: Int? = null,
        ex: Map<Char, Int> = emptyMap()
    ): (Char) -> String = { c ->
        val special = ex[c]
        when {
            special != null -> cp(special)
            c in 'A'..'Z' -> cp(upper + (c - 'A'))
            c in 'a'..'z' -> cp(lower + (c - 'a'))
            c in '0'..'9' && digit != null -> cp(digit + (c - '0'))
            else -> c.toString()
        }
    }

    private fun lowerTable(to: String): (Char) -> String = { c ->
        val l = c.lowercaseChar()
        if (l in 'a'..'z') to[l - 'a'].toString() else c.toString()
    }

    private val script = mapOf(
        'B' to 0x212C, 'E' to 0x2130, 'F' to 0x2131, 'H' to 0x210B, 'I' to 0x2110,
        'L' to 0x2112, 'M' to 0x2133, 'R' to 0x211B,
        'e' to 0x212F, 'g' to 0x210A, 'o' to 0x2134
    )
    private val fraktur = mapOf(
        'C' to 0x212D, 'H' to 0x210C, 'I' to 0x2111, 'R' to 0x211C, 'Z' to 0x2128
    )
    private val doubleStruck = mapOf(
        'C' to 0x2102, 'H' to 0x210D, 'N' to 0x2115, 'P' to 0x2119,
        'Q' to 0x211A, 'R' to 0x211D, 'Z' to 0x2124
    )
    private val italic = mapOf('h' to 0x210E)

    private const val SMALL_CAPS = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ"
    private const val UPSIDE = "ɐqɔpǝɟƃɥᴉɾʞlɯuodbɹsʇnʌʍxʎz"

    val all: List<Style> = listOf(
        Style("Normal", "Abc") { it.toString() },
        Style("Bold", "𝐁𝐨𝐥𝐝", math(0x1D400, 0x1D41A, 0x1D7CE)),
        Style("Italic", "𝐼𝑡𝑎𝑙𝑖𝑐", math(0x1D434, 0x1D44E, null, italic)),
        Style("Bold Italic", "𝑩𝒊", math(0x1D468, 0x1D482)),
        Style("Script", "𝒮𝒸𝓇𝒾𝓅𝓉", math(0x1D49C, 0x1D4B6, null, script)),
        Style("Bold Script", "𝓢𝓬𝓻𝓲𝓹𝓽", math(0x1D4D0, 0x1D4EA)),
        Style("Fraktur", "𝔉𝔯𝔞𝔨", math(0x1D504, 0x1D51E, null, fraktur)),
        Style("Bold Fraktur", "𝕭𝖔𝖑𝖉", math(0x1D56C, 0x1D586)),
        Style("Double", "𝔻𝕠𝕦𝕓𝕝𝕖", math(0x1D538, 0x1D552, 0x1D7D8, doubleStruck)),
        Style("Sans", "𝖲𝖺𝗇𝗌", math(0x1D5A0, 0x1D5BA, 0x1D7E2)),
        Style("Sans Bold", "𝗦𝗮𝗻𝘀", math(0x1D5D4, 0x1D5EE, 0x1D7EC)),
        Style("Sans Italic", "𝘚𝘢𝘯𝘴", math(0x1D608, 0x1D622)),
        Style("Mono", "𝙼𝚘𝚗𝚘", math(0x1D670, 0x1D68A, 0x1D7F6)),
        Style("Small Caps", "ᴄᴀᴘs", lowerTable(SMALL_CAPS)),
        Style("Upside", "ǝpᴉsdn", lowerTable(UPSIDE)),
        Style("Circled", "Ⓒⓘⓡ", { c ->
            when (c) {
                in 'A'..'Z' -> cp(0x24B6 + (c - 'A'))
                in 'a'..'z' -> cp(0x24D0 + (c - 'a'))
                in '1'..'9' -> cp(0x2460 + (c - '1'))
                '0' -> cp(0x24EA)
                else -> c.toString()
            }
        }),
        Style("Squared", "🄱🄾🅇", { c ->
            when (c) {
                in 'A'..'Z' -> cp(0x1F130 + (c - 'A'))
                in 'a'..'z' -> cp(0x1F130 + (c - 'a'))
                else -> c.toString()
            }
        }),
        Style("Wide", "Ｗｉｄｅ", { c ->
            if (c in '!'..'~') cp(0xFF01 + (c - '!')) else c.toString()
        }),
        Style("Strike", "S̶t̶r̶i̶k̶e̶", { c ->
            if (c.isLetterOrDigit()) "$c̶" else c.toString()
        }),
        Style("Underline", "U̲n̲d̲e̲r̲", { c ->
            if (c.isLetterOrDigit()) "$c̲" else c.toString()
        })
    )
}
